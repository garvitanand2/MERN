import { form1 } from './test';
import { a12 } from './sample'





class setHtml {
    static mainPage(form1, to) {
        form1.formbody.forEach(function (element) {
            if (to == "edit") {
                if (element.id == "save" || element.id == "reset") {
                    element.req = "no";
                }
            }
            var textfield = document.createElement(element.tag);
          
            if (element.req == "yes" && element.form == "yes") {
                textfield.setAttribute("placeholder", element.placeholder);
                textfield.setAttribute("type", element.type);
                textfield.setAttribute("id", element.id);
                textfield.setAttribute("class", element.class);
                textfield.setAttribute("name", element.name);
                document.getElementById(to).innerHTML += element.label;
                document.getElementById(to).appendChild(textfield);
            }
        })
    }
}



class table {
    // static createtable(definetab)
    // {
    //     let c = document.getElementById('3a');
    //     const table = document.createElement('Table');
    //     const row = document.createElement("tr");
    //     table.setAttribute('id', 'myTable');
    //     table.setAttribute("style", "text-align:center; border-radius: 2px; background-color:	#008000; width: 60%; margin: 0 auto; ");
    //     let t = definetab.headercol.length;
    //     row.setAttribute("class", "table table-hover table-bordered");
    //     for (let i = 0; i < t; i++) {
    //         let headerCell = document.createElement("TH");
    //         headerCell.setAttribute("id", definetab.headercol[i].id);
    //         headerCell.setAttribute("class", "table table-hover table-bordered");
    //         headerCell.setAttribute("style", "text-align:center; width:20%; margin: 0 auto;  background-color: #090909 ");
    //         headerCell.innerHTML = definetab.headercol[i].title;
    //         row.appendChild(headerCell);
    //     }
    //     let hasData = Object.keys(JSON.parse(localStorage.getItem('data'))).length
    //     if (hasData > 0) {
    //         table.appendChild(row);
    //         var local_data = localStorage.getItem('data');
    //         var local_data = JSON.parse(local_data);
    //         var ele = [];
    //         definetab.headercol.forEach(function (element) {
    //             ele.push(element.id);
    //         });
    //         for (var i = 0; i < local_data.length; i++) {
    //             var row1 = table.insertRow();
    //             var prow = local_data[i];
    //             var prowLength = Object.keys(prow).length;
    //             for (var j = 1; j < prowLength + 1; j++) {
    //                 var c1 = row1.insertCell();
    //                 const temp = ele[j - 1];
    //                 let a = prow[temp];
    //                 c1.innerHTML = a;
    //             }
    //             let c2 = row1.insertCell();
    //             c2.innerHTML = "<button  id='edit_" + i + "' class='btn btn-success' name='edit' onclick='edit( this.parentNode.parentNode.rowIndex)'  type='button' '>Edit</button>";
    //             let c3 = row1.insertCell();
    //             c3.innerHTML = "<button id='del_" + i + "' class='btn btn-danger' name='delete' type='button'>Delete</button>";
    //         }

    //         c.appendChild(table);
    //         local_data.forEach((elem, i) => {
    //             const delBtn = document.getElementById("del_" + i);
    //             if (delBtn) {
    //                 delBtn.onclick = function (e) {
    //                     editDelete.delete_data(i, definetab);
    //                 }
    //             }
    //         })
    //         local_data.forEach((elem, i) => {
    //             const editBtn = document.getElementById("edit_" + i);
    //             if (editBtn) {
    //                 editBtn.onclick = function (e) {
    //                     editDelete.edit_data(i);
    //                 }
    //             }
    //         })

    //     } // End of if
    //     else {
    //         document.getElementById('3a').innerHTML = '<h1>No data to show</h1>';
    //     }
    // }

    static newtable(form1) {

        let c = document.getElementById('3a');
        const table = document.createElement('Table');
        table.setAttribute('id', 'myTable');
        table.setAttribute("style", "text-align:center; border-radius: 2px; background-color:	#008000; width: 60%; margin: 0 auto; ");
        c.appendChild(table);
        const row = document.createElement("tr");
        let d = document.getElementById("myTable");
        d.appendChild(row);

        let t = form1.formbody.length;
        for (let i = 0; i < t; i++)
        {
            let headerCell = document.createElement("TH");
            headerCell.setAttribute("id", form1.formbody[i].id);
            headerCell.setAttribute("class", "table table-hover table-bordered");
            headerCell.setAttribute("style", "text-align:center; width:20%; margin: 0 auto;  background-color: #090909 ");
            
            if(form1.formbody[i].table == "yes")
            {
                headerCell.innerHTML =  form1.formbody[i].id
                row.appendChild(headerCell);
            }
        }
       
        let hasData = Object.keys(JSON.parse(localStorage.getItem('data'))).length

        if (hasData > 0) {
        //     table.appendChild(row);
            var local_data = localStorage.getItem('data');
            var local_data = JSON.parse(local_data);
            var ele = [];
            form1.formbody.forEach(function (element) {
                ele.push(element.id);
            });
            for (var i = 0; i < local_data.length; i++) {
                var row1 = table.insertRow();
                var prow = local_data[i];
                var prowLength = Object.keys(prow).length;
                for (var j = 1; j < prowLength + 1; j++) {
                    var c1 = row1.insertCell();
                    const temp = ele[j - 1];
                    let a = prow[temp];
                    c1.innerHTML = a;
                }
                let c2 = row1.insertCell();
                c2.innerHTML = "<button  id='edit_" + i + "' class='btn btn-success' name='edit' onclick='edit( this.parentNode.parentNode.rowIndex)'  type='button' '>Edit</button>";
                let c3 = row1.insertCell();
                c3.innerHTML = "<button id='del_" + i + "' class='btn btn-danger' name='delete' type='button'>Delete</button>";
            }

            c.appendChild(table);
            local_data.forEach((elem, i) => {
                const delBtn = document.getElementById("del_" + i);
                if (delBtn) {
                    delBtn.onclick = function (e) {
                        editDelete.delete_data(i, form1);
                    }
                }
            })
            local_data.forEach((elem, i) => {
                const editBtn = document.getElementById("edit_" + i);
                if (editBtn) {
                    editBtn.onclick = function (e) {
                        editDelete.edit_data(i);
                    }
                }
            })

        } // End of if
        else {
            document.getElementById('3a').innerHTML = '<h1>No data to show</h1>';
        }
    }

}



class editDelete {
    static delete_data(o, definetab) {
        var local_data = localStorage.getItem('data');
        var local_data = JSON.parse(local_data);
        local_data.splice(o, 1);
        localStorage.removeItem('data');
        localStorage.setItem('data', JSON.stringify(local_data));
        document.getElementById('3a').innerHTML = ""
        table.newtable(form1)
    }

    static edit_data(i) {
        let div = document.getElementById('edit');
        div.innerHTML = ""
        div.innerHtml = setHtml.mainPage(form1, "edit");
        let theDiv = document.getElementById('edit').children;
        let check = Object.values(theDiv);
        var local_data = localStorage.getItem('data');
        var local_data = JSON.parse(local_data);
        let a = local_data[i];
        let key = Object.keys(local_data[i]);
        for (let i = 0; i < check.length; i++) {
            check[i].value = a[key[i]];
        }
        let setid = document.getElementById("dataid");
        setid.value = a.id;
        $('#myModal').modal('show');
    }

}

class start {
    static submit() {
        $("#save").click(function () {
            let login_data = {};
            let nodelist = document.getElementsByTagName("input");
            let check = Object.values(nodelist);
            check.forEach(function (element) {
                var key = element.placeholder;
                let value = element.value;
                if (key != "") {
                    login_data[key] = value;
                  
                }
               
            });
            for (let [key, value] of Object.entries(login_data)) {
                let check = login_data[key];
                document.getElementById(key).setAttribute("style", "");
                if (check == "") {
                    alert("Please enter " + key);
                    document.getElementById(key).setAttribute("style", "border: 5px solid red;");
                    document.getElementById(key).focus();
                    return;
                }
                // Email validation
                if (key == "Email") {
                    let email = login_data[key];
                    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
                    if (!filter.test(email)) {
                        alert('Please provide a valid email address');
                        document.getElementById(key).setAttribute("style", "border: 5px solid red;");
                        document.getElementById("Email").focus();
                        return;
                    }
                }
                // Phone number validation
                if (key == "Phone") {
                    let phoneno = /^\d{10}$/;
                    let phn = login_data[key];
                    if (!phoneno.test(phn)) {
                        alert('Please provide a valid contact number');
                        document.getElementById(key).setAttribute("style", "border: 5px solid red;");
                        document.getElementById(key).focus();
                        return;
                    }
                }
            }
            let refresh = document.getElementById("login");
            refresh .innerHTML = ""
            setHtml.mainPage(form1, "login");

            let local_data = JSON.parse(localStorage.getItem('data')) || [];
            const len = local_data.length;
            login_data["id"] = len + 1;
            local_data.push(login_data);
            localStorage.setItem('data', JSON.stringify(local_data));
            $('#exTab1 a[href="' + '#3a' + '"]').tab('show');
            let div = document.getElementById('3a');
            div.innerHTML = ""
            table.newtable(form1)

        });
    } // End of submit method
}

setHtml.mainPage(form1, "login");
table.newtable(form1)
start.submit();
$(document).ready(function () {
    $("#update").click(function () {

        let login_data = {};
        let nodelist = document.getElementsByTagName("input");
        let check = Object.values(nodelist);
        check.forEach(function (element) {
            let key = element.placeholder;
            let value = element.value;
            if (key != "") {
                login_data[key] = value;
            }
        });
        let key = Object.keys(login_data);
        let val = Object.values(login_data);
        let id = document.getElementById('dataid').value;
        let local_data = JSON.parse(localStorage.getItem('data'));
        login_data["id"] = id;
        let update_data = [];
        update_data.push(login_data);
        local_data = local_data.map(obj => update_data.find(o => o.id == obj.id) || obj);
        localStorage.setItem('data', JSON.stringify(local_data));
        $('#exTab1 a[href="' + '#3a' + '"]').tab('show');
        let div = document.getElementById('3a');
        div.innerHTML = ""
        table.newtable(form1)

    });
});

