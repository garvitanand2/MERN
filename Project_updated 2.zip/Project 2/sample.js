let a12 = "He";
export default {a12}; 