// const path = require('path');
// module.exports = {
//     entry: './src/js/index.js',
//     output:{
//         path:path.resolve(__dirname,'Project 2'),
//         filenmae: 'bundle.js'
//     },
//     mode: 'development'
// };

const path = require('path');

module.exports = {
  entry: './index.js',
  output: {
    filename: 'main.js',
    path: path.resolve(__dirname, 'dist')
  },
  devServer:{
      contentBase: './dist'
  }
};