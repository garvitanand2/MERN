let a12 = "He";
export {a12}; 