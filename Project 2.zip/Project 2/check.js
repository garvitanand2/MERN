(No subject)
Naveen Kumar
Thu 22/08/2019 16:54
const definetab={
  title:"store data table",
  delebtn:"true",
  editbtn:"true",
  headercol:[ {
     id:"name",
    title:"Firstname",
    type:"Text",
    required:false,
    editable:true 
  }  ,
   { id:"lastname",
  title:"Lastname",
  type:"Text",
  required:false,
  editable:true } ,
  {
    id:"gender",
 title:"Sex",
 type:"radio",
 required:false,
 editable:true }
  ]
} ;

 let infoarr=[];
 let infoobj={};
//let type=definetab.headercol[1].title;

function createtable(definetab){

 let c=document.getElementById('show');
 const table=document.createElement('Table');
 const row=document.createElement("tr");
  table.setAttribute('id','myTable');
  table.setAttribute("style", "text-align:center; border-radius: 1px; width: 50%; margin: 0 auto; background-color:ghostwhite; ");
  table.setAttribute("class","table table-hover table-bordered");
   let t=definetab.headercol.length;
   row.setAttribute("class","table table-hover table-bordered");
   console.log(t);
   for (let i = 0; i <t; i++) {
     let headerCell = document.createElement("TH");
     console.log(definetab.headercol[i].id);
     headerCell.setAttribute("id",definetab.headercol[i].id);
     headerCell.setAttribute("class","table table-hover table-bordered");
     headerCell.setAttribute("style", "text-align:center; width:20%; margin: 0 auto; background-color:ghostwhite; ");
     headerCell.innerHTML = definetab.headercol[i].title;
     row.appendChild(headerCell);
 } let headerCell = document.createElement("TH");
 headerCell.innerHTML = "action to be performed";
 headerCell.setAttribute("class","table table-hover table-bordered");
     headerCell.setAttribute("style", "text-align:center; width:20%; margin: 0 auto; background-color:ghostwhite; ");
 row.appendChild(headerCell);
 console.log(row);
 table.appendChild(row);
//let tb=document.getElementById('myTable');
var row1=table.insertRow();
row1.setAttribute("class","table table-hover table-bordered");
   var col1=row1.insertCell(0);
   var col2=row1.insertCell(1);
   var col3=row1.insertCell(2);
   col1.innerHTML='naveen';
   col2.innerHTML='kumar ';
   col3.innerHTML='male';
     c.appendChild(table);
}  
createtable(definetab);

function addrow()
{
  let t=document.getElementById("myTable");
  let row1=t.insertRow();
  //row1.setAttribute("id","1");
 // row1.setAttribute("contenteditable","true");
  row1.setAttribute("class","table table-hover table-bordered");
  let n=definetab.headercol.length;
  for(let i=0;i<n;i++){
    let col1=row1.insertCell(i);
    let r=definetab.headercol[i].type;
    let p=definetab.headercol[i].title;
     if(r=="radio"){
        col1.innerHTML='<input type='+r+' name="gender" value="male" id='+i+'> Male <input type='+r+' name="gender" value="female" id='+i+'> Female<br> <input type='+r+' name="gender" value="other" id='+i+'> Other<br> ';
     }
     else{
    col1.innerHTML='<input type='+r+' name='+p+' placeholder='+p+' id='+i+' />';
     }
    }
  let col1=row1.insertCell(3);
  col1.innerHTML="<button class='btn btn-success' name='edit'  onclick='ADD(this)' type='button' '>Add </button>";
  }
 
 
function ADD(btn){
  var row = btn.parentNode.parentNode;
  var index=row.rowIndex;
  let t=document.getElementById("myTable");
  for(let i=0; i<3;i++){
    let key=document.getElementById(i).name;
    let val=document.getElementById(i).value;
    if(key=='gender'){
    let txt=document.querySelector('input[name="gender"]:checked').value;
    infoobj[key]=txt;
    t.rows[index].cells[i].innerHTML =txt;
  }else {
    let key=document.getElementById(i).name;
    //let val=document.getElementById(i).value;
     console.log(val);
     t.rows[index].cells[i].innerHTML =val;
     infoobj[key]=val;
  }
  }   infoarr.push(infoobj);
  infoobj={};
  if(definetab.delebtn=="true"){
   // t.rows[index].cells[3].innerHTML="";
   t.rows[index].cells[3].innerHTML= "<button class='btn btn-success' name='edit'  onclick='edit(this)' type='button' '>Update</button>";
   }
    if(definetab.editbtn=="true"){
    // t.rows[index].cells[3].innerHTML="";
    t.rows[index].cells[3].innerHTML += "<button class='btn btn-danger' name='edit'  onclick='update(this)' type='button' '>Delete</button>";
    }
    if(definetab.editbtn=="false"){
      t.rows[index].cells[3].innerHTML="";
    }    
  }
 
 
  function edit(btn){
    let row = btn.parentNode.parentNode;
    let index=row.rowIndex;
    console.log(index);  
    let n=definetab.headercol.length;
    let t=document.getElementById("myTable");
    for(let i=0;i<n;i++){
        let r=definetab.headercol[i].type;
        let p=definetab.headercol[i].title;
       if(r=="radio"){
        let gen=t.rows[index].cells[i].innerHTML;
         switch(gen){
          case 'male':
              t.rows[index].cells[i].innerHTML ='<input type='+r+' name="gender" value="male" id='+i+' checked> Male <input type='+r+' name="gender" value="female" id='+i+'> Female<br> <input type='+r+' name="gender" value="other" id='+i+'> Other<br> ';
             break;
             case 'female':
                t.rows[index].cells[i].innerHTML ='<input type='+r+' name="gender" value="male" id='+i+'> Male <input type='+r+' name="gender" value="female" id='+i+' checked> Female<br> <input type='+r+' name="gender" value="other" id='+i+'> Other<br> ';
              break;
              default :
              t.rows[index].cells[i].innerHTML ='<input type='+r+' name="gender" value="male" id='+i+'> Male <input type='+r+' name="gender" value="female" id='+i+'> Female<br> <input type='+r+' name="gender" value="other" id='+i+' checked> Other<br> ';
              }
            }
       if(r=="Text"){
        console.log(t.rows[index].cells[i].innerHTML);
       t.rows[index].cells[i].innerHTML ='<input type='+r+' name='+p+' placeholder='+p+' id='+i+' value='+t.rows[index].cells[i].innerHTML+' >';
          // console.log('hello');
      }  

  }
  t.rows[index].cells[3].innerHTML= "<button class='btn btn-success' name='edit'  onclick='save(this)' type='button' '>Save</button>";




}
