console.log("Imported Module"); 

let form1 = {
    formbody: [
        {
            id: "id",
            tag: "input",
            type: "text",
            placeholder: "ID",
            label: "Employee ID",
            class: "form-control",
            space: "BR",
            req: "yes",
            table: "yes",
            form: "no"
        },
        {
            id: "Firstname",
            tag: "input",
            type: "text",
            placeholder: "Firstname",
            label: "First Name",
            class: "form-control",
            space: "BR",
            req: "yes",
            table: "yes",
            form: "yes"
        },
        {
            id: "Lastname",
            tag: "input",
            type: "text",
            placeholder: "Lastname",
            label: "Last Name",
            class: "form-control",
            space: "BR",
            req: "yes",
            table: "yes",
            form: "yes"
        },
        {
            id: "Email",
            tag: "input",
            type: "text",
            placeholder: "Email",
            label: "Email",
            class: "form-control",
            space: "BR",
            req: "yes",
            table: "yes",
            form: "yes"
        },
        {
            id: "Phone",
            tag: "input",
            type: "text",
            placeholder: "Phone",
            label: "Mobile Number",
            class: "form-control",
            space: "BR",
            req: "yes",
            table: "yes",
            form: "yes"
        },

        {
            id: "save",
            tag: "input",
            type: "submit",
            placeholder: "",
            label: "",
            class: "btn btn-success",
            req: "yes",
            table: "no",
            form: "yes"
        },
        {
            id: "reset",
            tag: "input",
            type: "reset",
            placeholder: "",
            label: "",
            class: "btn btn-danger",
            req: "yes",
            table: "no",
            form: "yes"
        },
    ]
}




// const definetab = {
//     title: "store data table",
//     headercol: [

//         {
//             id: "id",
//             title: "Employee Id",

//         },
//         {
//             id: "Firstname",
//             title: "First Name",

//         },
//         {
//             id: "Lastname",
//             title: "Last Name",

//         },
//         {
//             id: "Email",
//             title: "Email",

//         },
//         {
//             id: "Phone",
//             title: "Mobile",

//         },
//         {
//             id: "Update",
//             title: "Update",
//         },
//         {
//             id: "Delete",
//             title: "Delete",

//         }
//     ]
// };

export  {form1};
